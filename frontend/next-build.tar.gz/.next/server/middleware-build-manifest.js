globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/build-1786498825882-47c69cb8/_buildManifest.js",
    "static/build-1786498825882-47c69cb8/_ssgManifest.js",
    "static/build-1786498825882-47c69cb8/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/16d3_j7a__suf.js",
    "static/chunks/3rxl-jt3pdxgx.js",
    "static/chunks/0mk1g55o6kl1e.js",
    "static/chunks/2gqi9i6h3hc77.js",
    "static/chunks/turbopack-0c0zemkbsu8e9.js"
  ]
};
