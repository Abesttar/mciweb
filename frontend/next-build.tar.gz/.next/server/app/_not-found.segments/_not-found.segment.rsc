1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/1-liusq3ijmxj.js","/_next/static/chunks/1pq2bwade-rgg.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
3:I[37457,["/_next/static/chunks/1-liusq3ijmxj.js","/_next/static/chunks/1pq2bwade-rgg.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"build-1786498825882-47c69cb8"}
