:HL["/_next/static/chunks/13cm9sognwwkb.css","style"]
:HL["/_next/static/chunks/0d5nqup8rh62l.css","style"]
:HL["/_next/static/chunks/16z0mkuf_6cp1.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"build-1786498825882-47c69cb8"}
