1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/1-liusq3ijmxj.js","/_next/static/chunks/1pq2bwade-rgg.js","/_next/static/chunks/14mrh2-p_w84d.js"],"ClientSegmentRoot"]
3:I[39126,["/_next/static/chunks/1-liusq3ijmxj.js","/_next/static/chunks/1pq2bwade-rgg.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/3prlfobvnaxpn.js"],"default"]
4:I[39756,["/_next/static/chunks/1-liusq3ijmxj.js","/_next/static/chunks/1pq2bwade-rgg.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
5:I[37457,["/_next/static/chunks/1-liusq3ijmxj.js","/_next/static/chunks/1pq2bwade-rgg.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/3prlfobvnaxpn.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"build-1786498825882-47c69cb8"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
