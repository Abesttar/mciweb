1:"$Sreact.fragment"
3:I[97367,["/_next/static/chunks/1-liusq3ijmxj.js","/_next/static/chunks/1pq2bwade-rgg.js","/_next/static/chunks/14mrh2-p_w84d.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"build-1786498825882-47c69cb8"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/dashboard;307;"}
