module.exports=[60078,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_activity-logs_page_actions_0ysdc5y.js.map