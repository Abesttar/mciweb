module.exports=[63027,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_students_profile_page_actions_14_d_3t.js.map