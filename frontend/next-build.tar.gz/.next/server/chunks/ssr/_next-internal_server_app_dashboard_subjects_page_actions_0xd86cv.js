module.exports=[13537,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_subjects_page_actions_0xd86cv.js.map