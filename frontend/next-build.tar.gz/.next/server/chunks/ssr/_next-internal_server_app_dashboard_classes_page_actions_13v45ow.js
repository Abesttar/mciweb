module.exports=[48124,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_classes_page_actions_13v45ow.js.map