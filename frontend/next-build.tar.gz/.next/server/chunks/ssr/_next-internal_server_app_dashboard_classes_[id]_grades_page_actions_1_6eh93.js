module.exports=[55151,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_classes_%5Bid%5D_grades_page_actions_1_6eh93.js.map