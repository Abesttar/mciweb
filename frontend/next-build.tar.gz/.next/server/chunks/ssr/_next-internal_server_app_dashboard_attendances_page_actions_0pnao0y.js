module.exports=[85246,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_attendances_page_actions_0pnao0y.js.map