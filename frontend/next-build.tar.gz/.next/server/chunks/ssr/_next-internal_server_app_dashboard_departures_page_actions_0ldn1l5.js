module.exports=[29717,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_departures_page_actions_0ldn1l5.js.map