module.exports=[56777,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_enrollments_page_actions_0a4pybz.js.map