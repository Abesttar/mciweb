module.exports=[44282,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_teachers_page_actions_0xwj1hl.js.map