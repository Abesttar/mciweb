module.exports=[51577,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_dashboard_classes_%5Bid%5D_raport_%5BenrollmentId%5D_page_actions_16-buk2.js.map