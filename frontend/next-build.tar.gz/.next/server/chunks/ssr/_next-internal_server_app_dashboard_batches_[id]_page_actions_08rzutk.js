module.exports=[23630,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_batches_%5Bid%5D_page_actions_08rzutk.js.map